using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HotelSystem
{
    public class Customer
    {
        public int CusID { get; set; }
        public string cusName { get; set; }
        public int roomNum { get; set; }
        public string billStatus { get; set; }
        public double BillPaid { get; set; }
        public double BillLeft { get; set; }
        public string CItime { get; set; }
        public string COtime { get; set; }
        public string cusContact { get; set; }
        public int stayDur;
    }
    public class Hotel
    {
        public static Customer c = new Customer();
        private static int TVisitors=0;
        static int rent = 2000;
        static string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Mahnoor\source\repos\ConsoleApp8\ConsoleApp8\Hotel.mdf;Integrated Security=True;User Instance=True";
        static void Main(string[] args)
        {
            bool f = true;
            while (f)
            {
                Console.WriteLine("Select Operation");
                Console.WriteLine("1.Check-In Customer");
                Console.WriteLine("2.View Customer ");
                Console.WriteLine("3.Check-Out Customer");
                Console.WriteLine("4.Delete Customer");
                Console.WriteLine("5.View Available Rooms ");
                Console.WriteLine("6.View Total Visitors ");
                Console.WriteLine("7.Exit ");
                int n = int.Parse(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        Add();
                        break;
                    case 2:
                        View();
                        break;
                    case 3:
                        checkout();
                        break;
                    case 4:
                        Delete();
                        break;
                    case 5:
                        ViewRooms();
                        break;
                    case 6:
                        Console.WriteLine("Total Visitors:" + TVisitors);
                        break;
                    case 7:
                        f = false;
                        break;
                    default:
                        Console.WriteLine("Invalid Choice!");
                        break;
                }
                Console.WriteLine("\n\n");
            }

        }
        public static void Add()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            Console.WriteLine("Enter Customer Name:");
            c.cusName = Console.ReadLine();
            Console.WriteLine("Enter Contact Number:");
            c.cusContact = Console.ReadLine();
            Console.WriteLine("Enter Number of Days of Stay:");
            c.stayDur = int.Parse(Console.ReadLine());
            c.billStatus = "to be paid";
            c.BillLeft = c.stayDur * rent;
            c.BillPaid = 0;
            c.COtime = "none";
            var d = DateTime.Now;
            c.CItime = (d.Date).ToString();

            connection.Open();
            string query = "select * from Room where RoomStatus='free'";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                c.roomNum = reader.GetInt32(reader.GetOrdinal("RoomId"));
            }
            else
            {
                Console.WriteLine("Not Availabe");
            }
            connection.Close();

            connection.Open();
            string query0 = "update Room set RoomStatus = 'Occupied' where RoomId='" + c.roomNum + "'";
            SqlCommand cmd0 = new SqlCommand(query0, connection);
            int NumberOfInsertedRows = cmd0.ExecuteNonQuery();
            connection.Close();

            string query1 = "insert into Customer(CusName, Room, billStatus,billPaid,billLeft,CITime,COTime,cusContact,stay) values('" + c.cusName + "','" + c.roomNum + "','" + c.billStatus + "','"+c.BillPaid+"','"+c.BillLeft+"','" + c.CItime + "','" + c.COtime + "','" + c.cusContact + "','"+ c.stayDur+"')";
            connection.Open();
            SqlCommand cmd1 = new SqlCommand(query1, connection);
            int NumberOfInsertedRows1 = cmd1.ExecuteNonQuery();
            connection.Close();

            TVisitors++;
            connection.Open();
            string query11 = "select * from Customer where Room='"+c.roomNum+"'";
            SqlCommand cmd11 = new SqlCommand(query11, connection);
            SqlDataReader reader11 = cmd11.ExecuteReader();
            if (reader11.HasRows)
            {
                reader11.Read();
                c.CusID = reader11.GetInt32(reader11.GetOrdinal("cusID"));
            }
            else
            {
                Console.WriteLine("Not Availabe");
            }
            connection.Close();
            Console.WriteLine("**Customer ID:"+c.CusID+"\n**Allotted Room number:" + c.roomNum);
        }
        public static void checkout()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            Console.WriteLine("Enter Customer ID:");
            c.CusID = int.Parse(Console.ReadLine());
            string query2 = "select * from Customer where cusID='" + c.CusID + "'";
            SqlCommand cmd2 = new SqlCommand(query2, connection);
            SqlDataReader reader1 = cmd2.ExecuteReader();
            if (reader1.HasRows)
            {
                reader1.Read();
                c.BillLeft = reader1.GetDouble(reader1.GetOrdinal("billLeft"));
                c.roomNum= reader1.GetInt32(reader1.GetOrdinal("Room"));
            }
            else
            {
                Console.WriteLine("Not Found");
            }
            connection.Close();

            var d = DateTime.Now;
            c.COtime = (d.Date).ToString();
            string query = "update Room set RoomStatus='free' where RoomId = '" + c.roomNum + "'";
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.ExecuteNonQuery();
            Console.WriteLine("Bill to be Paid:" + c.BillLeft);
            Console.WriteLine("Enter amount to pay:");
            c.BillPaid = double.Parse(Console.ReadLine());
            if (c.BillPaid == c.BillLeft || c.BillPaid > c.BillLeft)
            {
                Console.WriteLine("Bill Cleared!");
                c.billStatus = "Paid";
                c.BillLeft = 0;
            }
            else if (c.BillPaid < c.BillLeft)
            {
                c.BillLeft = c.BillLeft - c.BillPaid;
                Console.WriteLine("Bill to be Paid:" + c.BillLeft);
                c.billStatus = "Paritially Paid";
            }
            string query1 = "update Customer set COTime = '" + c.COtime + "', billPaid = '" + c.BillPaid + "', billLeft= '" + c.BillLeft + "', billStatus = '" + c.billStatus + "' where Room='"+c.roomNum+"'";
            SqlCommand cmd1 = new SqlCommand(query1, connection);
            cmd1.ExecuteNonQuery();
            connection.Close();
        }
        public static void Delete()
        {
            Console.WriteLine("Enter Customer ID:");
            c.CusID = int.Parse(Console.ReadLine());
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query3 = "delete from Customer where cusID = '" + c.CusID + "'";
            SqlCommand cmd3 = new SqlCommand(query3, connection);
            cmd3.ExecuteNonQuery();
            connection.Close();
            Console.WriteLine("Customer Deleted!");
        }
        public static void ViewRooms()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            string query = "select * from Room where RoomStatus = 'free'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Console.WriteLine("Room ID: {0}    RoomStatus: {1}", reader.GetInt32(reader.GetOrdinal("RoomId")), reader.GetString(reader.GetOrdinal("RoomStatus")));
                }
            }
            else
            {
                Console.WriteLine("Not Found");
            }

        }
        public static void View()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            Console.WriteLine("Enter Customer ID:");
            c.CusID = int.Parse(Console.ReadLine());
            string query = "select * from Customer where cusID='"+c.CusID+"'";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                Console.WriteLine("CustomerID: {0} \nName: {1} \nRoom: {2} \nBill Status: {3} \nBillPaid: {4} \nBillLeft: {5} \nCheck-In: {6} \nCheck-Out: {7} \nContact: {8} \nStayDuration: {9}Days", reader.GetInt32(reader.GetOrdinal("cusID")), reader.GetString(reader.GetOrdinal("cusName")), reader.GetInt32(reader.GetOrdinal("Room")), reader.GetString(reader.GetOrdinal("BillStatus")), reader.GetDouble(reader.GetOrdinal("BillPaid")), reader.GetDouble(reader.GetOrdinal("BillLeft")), reader.GetString(reader.GetOrdinal("CITime")), reader.GetString(reader.GetOrdinal("COTime")), reader.GetString(reader.GetOrdinal("cusContact")), reader.GetInt32(reader.GetOrdinal("stay")));
            }
            else
            {
                Console.WriteLine("Data not Found!");
            }
            
        }

    }
}
