﻿using System;
using System.Windows;
using System.Speech.Synthesis;
using System.Speech.Recognition;


namespace WpfApp4
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            SpeechSynthesizer ss = new SpeechSynthesizer();
            ss.Speak(tb1.Text);
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            SpeechRecognitionEngine sr = new SpeechRecognitionEngine();
            Grammar words = new DictationGrammar();
            sr.LoadGrammar(words);

            try
            {
                sr.SetInputToDefaultAudioDevice();
                RecognitionResult r = sr.Recognize();
                tb1.Text = r.Text;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sr.UnloadAllGrammars(); 
            }
        }
    }
}
