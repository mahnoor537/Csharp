﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int player1 = 0;
        int player2 = 1;
        int[,] arr = new int[3, 3] {
                     {-1, -1, -1} ,  
                     {-1, -1, -1} ,  
                     {-1, -1, -1}   
        };
        int turn = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            arr[0,0] = turn;
            b1.Content = placeMark(turn);
            bool c=Checkwin(0,0);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                {
                    turn = changeTurn(turn);
                    if (turn==player1)
                        tb1.Text = "Player O's turn";
                    else
                        tb1.Text = "Player X's turn";
                }
            }

        }

        private bool checkdraw()
        {
            int count= 0;
            for (int i=0;i<3;i++)
            {
                for (int j=0;j<3;j++)
                {
                    if (arr[i,j] == -1)
                        count++;
                }
            }
            if (count == 0)
                return true;
            else
                return false;
        }

        private object placeMark(int turn)
        {
            if (turn == 1)
                return 'X';
            else
               return 'O';
        }

        private void declareWin()
        {
            if (turn == 1)
                tb1.Text = "Player X has WON!";
            else
                tb1.Text = "Player 0 has WON!";
            init();
        }
        
        private void init()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i,j] = -1;
                }
            }
            b1.Content = b2.Content = b3.Content = b4.Content = b5.Content = b6.Content = b7.Content = b8.Content = b9.Content = " ";

        }
        private bool Checkwin(int r,int c)
        {
            if (r==0 && c==0)
            {
                if (((arr[r,c+1] == arr[r,c]) && (arr[r,c+2] == arr[r,c])) || ((arr[r+1,c] == arr[r,c]) && (arr[r+2,c] == arr[r,c])) || ((arr[r + 1,c+1] == arr[r,c]) && (arr[r + 2,c+2] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r==0 && c==1)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c + 1] == arr[r,c])) || ((arr[r + 1,c] == arr[r,c]) && (arr[r + 2,c] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 0 && c == 2)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c - 2] == arr[r,c])) || ((arr[r + 1,c] == arr[r,c]) && (arr[r + 2,c] == arr[r,c])) || ((arr[r + 1,c - 1] == arr[r,c]) && (arr[r + 2,c - 2] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r==1 && c==0)
            {
                if (((arr[r,c + 1] == arr[r,c]) && (arr[r,c + 2] == arr[r,c])) || ((arr[r - 1,c] == arr[r,c]) && (arr[r + 1,c] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 1 && c == 1)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c + 1] == arr[r,c])) || ((arr[r + 1,c] == arr[r,c]) && (arr[r - 1,c] == arr[r,c])) || ((arr[r - 1,c - 1] == arr[r,c]) && (arr[r + 1,c + 1] == arr[r,c])) || ((arr[r - 1,c + 1] == arr[r,c]) && (arr[r + 1,c - 1] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 1 && c == 2)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c - 2] == arr[r,c])) || ((arr[r + 1,c] == arr[r,c]) && (arr[r -1,c] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 2 && c == 0)
            {
                if (((arr[r,c +1] == arr[r,c]) && (arr[r,c + 2] == arr[r,c])) || ((arr[r - 1,c] == arr[r,c]) && (arr[r - 2,c] == arr[r,c])) || ((arr[r - 1,c + 1] == arr[r,c]) && (arr[r - 2,c + 2] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 2 && c == 1)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c + 1] == arr[r,c])) || ((arr[r - 1,c] == arr[r,c]) && (arr[r - 2,c] == arr[r,c])))
                {
                    return true;
                }
            }
            else if (r == 2 && c == 2)
            {
                if (((arr[r,c - 1] == arr[r,c]) && (arr[r,c -2] == arr[r,c])) || ((arr[r - 1,c] == arr[r,c]) && (arr[r - 2,c] == arr[r,c])) || ((arr[r - 1,c-1] == arr[r,c]) && (arr[r - 2,c-2] == arr[r,c])))
                {
                    return true;
                }
            }
            return false;
        }

        private int changeTurn(int turn)
        {
            if (turn == player1)
                turn = player2;
            else
                turn = player1;
            return turn;
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            arr[0,1] = turn;
            b2.Content = placeMark(turn);
            bool c = Checkwin(0, 1);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            arr[0,2] = turn;
            b3.Content = placeMark(turn);
            bool c = Checkwin(0, 2);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            arr[1,0] = turn;
            b4.Content = placeMark(turn);
            bool c = Checkwin(1, 0);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B5_Click(object sender, RoutedEventArgs e)
        {
            arr[1,1] = turn;
            b5.Content = placeMark(turn);
            bool c = Checkwin(1, 1);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B6_Click(object sender, RoutedEventArgs e)
        {
            arr[1,2] = turn;
            b6.Content = placeMark(turn);
            bool c = Checkwin(1, 2);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B9_Click(object sender, RoutedEventArgs e)
        {
            arr[2,0] = turn;
            b9.Content = placeMark(turn);
            bool c = Checkwin(2, 0);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B8_Click(object sender, RoutedEventArgs e)
        {
            arr[2,1] = turn;
            b8.Content = placeMark(turn);
            bool c = Checkwin(2, 1);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void B7_Click(object sender, RoutedEventArgs e)
        {
            arr[2,2] = turn;
            b7.Content = placeMark(turn);
            bool c = Checkwin(2, 2);
            if (c == true)
                declareWin();
            else
            {
                if (checkdraw())
                {
                    tb1.Text = "*****Its a DRAW*****";
                    init();
                }
                else
                    turn = changeTurn(turn);
            }

        }

        private void Reset(object sender, RoutedEventArgs e)
        {
            init();
            tb1.Text = " ";
        }
    }
}
