using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace BankingSystem
{
    public class Bank
    {
        private string UserName;
        private static int AccountID=0;
        private int pin;
        private double balance;
        private double Tamount;
        private string Ttype;
        private string Tdate;


        public void AddUser()
        {
            Console.WriteLine("Enter User Name:");
            UserName = Console.ReadLine();
            AccountID = AccountID + 1;
            Console.WriteLine("Enter pin:");
            pin = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Amount to deposit:");
            balance = double.Parse(Console.ReadLine());
            Tamount = balance;
            Ttype = "cash deposit";
            var d= DateTime.Now;
            Tdate = (d.Date).ToString();
            int id = getId();
            AccountID = id + 1;
            string line = AccountID + " " + pin + " "+ UserName + " " +balance + " " + Tamount + " " + Tdate+ " " + Ttype;
            System.IO.File.AppendAllText("data.txt","\n"+ line);
            Console.WriteLine("Your id is: " + AccountID);
        }
        public void Deposit()
        {
            Console.WriteLine("Enter Account ID:");
            AccountID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter pin:");
            pin = int.Parse(Console.ReadLine());
            string[] lines = System.IO.File.ReadAllLines("data.txt");
            bool f = false;
            for (int i=0;i<lines.Length;i++)
            {
                string[] tkn = lines[i].Split(' ');
                if (tkn[0] == AccountID.ToString() && tkn[1] == pin.ToString())
                {
                    Console.WriteLine("Enter Amount to deposit:");
                    Tamount = double.Parse(Console.ReadLine());
                    balance = balance + Tamount;
                    Ttype = "cash deposit";
                    var d = DateTime.Now;
                    Tdate = (d.Date).ToString();
                    string line2 = AccountID + " " + pin + " " + " " + UserName + " " + balance + " " + Tamount + " " + Tdate + " " + Ttype;
                    lines[i] = line2;
                    System.IO.File.WriteAllLines("data.txt", lines);
                    f = true;
                    break;
                }

            }
            if (f==true)
            {
                Console.WriteLine("Your transation is processed.");
            }
            else
            {
                Console.WriteLine("*****Invalid Account/pin, the transaction can't be processed*****");
            }

        }
        public void Withdraw()
        {
            Console.WriteLine("Enter Account ID:");
            AccountID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter pin:");
            pin = int.Parse(Console.ReadLine());
            string[] lines = System.IO.File.ReadAllLines("data.txt");
            bool f = false;
            double tax = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                string[] tkn = lines[i].Split(' ');
                if (tkn[0] == AccountID.ToString() && tkn[1] == pin.ToString())
                {
                    Console.WriteLine("Enter Amount to withdraw:");
                    Tamount = double.Parse(Console.ReadLine());
                    if (Tamount>50000)
                    {
                        tax = 0.05 * Tamount;
                    }
                    balance = balance - Tamount-tax;
                    Ttype = "cash withdrawl";
                    var d = DateTime.Now;
                    Tdate = (d.Date).ToString();
                    string line2 = AccountID + " " + pin + " " + " " + UserName + " " + balance + " " + Tamount + " " + Tdate + " "+ Ttype;
                    lines[i] = line2;
                    System.IO.File.WriteAllLines("data.txt", lines);
                    f = true;
                    break;
                }

            }
            if (f == true)
            {
                Console.WriteLine("Your transation is processed.");
            }
            else
            {
                Console.WriteLine("*****Invalid Account/pin, the transaction can't be processed*****");
            }

        }
        public void balanceInquiry()
        {
            Console.WriteLine("Enter Account ID:");
            AccountID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter pin:");
            pin = int.Parse(Console.ReadLine());
            string[] lines = System.IO.File.ReadAllLines("data.txt");
            bool f = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string[] tkn = lines[i].Split(' ');
                if (tkn[0] == AccountID.ToString() && tkn[1] == pin.ToString())
                {
                    Console.WriteLine("Your balance is:" + tkn[4]);
                    f = true;
                    break;
                }

            }
            if (f == true)
            {
                Console.WriteLine("Your transation is processed.");
            }
            else
            {
                Console.WriteLine("*****Invalid Account/pin, the transaction can't be processed*****");
            }

        }

        public int getId()
        {
            int count = 0;
            FileStream fid = new FileStream("data.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fid);
            while (sr.ReadLine() != null)
            {
                count++;
            }
            sr.Close();
            fid.Close();
            return count;
        }
        public void LastTransaction()
        {
            Console.WriteLine("Enter Account ID:");
            AccountID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter pin:");
            pin = int.Parse(Console.ReadLine());
            string[] lines = System.IO.File.ReadAllLines("data.txt");
            bool f = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string[] tkn = lines[i].Split(' ');
                if (tkn[0] == AccountID.ToString() && tkn[1] == pin.ToString())
                {
                    Console.WriteLine("Last Transaction Details:");
                    Console.WriteLine("Transaction type:"+tkn[9]+ " "+tkn[10]);
                    Console.WriteLine("Transaction Date and time:" + tkn[6]+ " " + tkn[7] + " "+ tkn[8]);
                    Console.WriteLine("Transaction Amount:" + tkn[5]);
                    f = true;
                    break;
                }

            }
            if (f == true)
            {
                Console.WriteLine("Your transation is processed.");
            }
            else
            {
                Console.WriteLine("*****Invalid Account/pin, the transaction can't be processed*****");
            }
        }

        public static void Main(string[] args)
        {
            bool x = true;
            Bank b= new Bank();
            while (x)
            {
                int n = b.showMenu();
                switch (n)
                {
                    case 1:
                        b.AddUser();
                        break;
                    case 2:
                        b.Deposit();
                        break;
                    case 3:
                        b.Withdraw();
                        break;
                    case 4:
                        b.balanceInquiry();
                        break;
                    case 5:
                        b.LastTransaction();
                        break;
                    case 6:
                        x = false;
                        break;
                    default:
                        Console.WriteLine("Invalid Choice\n\n");
                        break;
                }
            }
        }

        private int showMenu()
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Add User");
            Console.WriteLine("2. Deposit Money");
            Console.WriteLine("3. Withdraw money");
            Console.WriteLine("4. Balance Inquirey");
            Console.WriteLine("5. Last Transaction");
            Console.WriteLine("6. exit");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
    }

   
}
