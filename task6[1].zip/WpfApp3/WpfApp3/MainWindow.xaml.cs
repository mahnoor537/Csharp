﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Forms;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer;
        public MainWindow()
        {
            InitializeComponent();
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(500)
            };
            timer.Tick += new EventHandler(Timer_Tick);
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            s1.Value = Media1.Position.TotalSeconds;

        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            Media1.Play();
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            Media1.Pause();
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            Media1.Stop();
        }

        private void S2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Media1.Volume = (double)s2.Value;
        }

        private void S1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Media1.Position = TimeSpan.FromSeconds(s1.Value);
        }

        private void Media1_MediaOpened(object sender, RoutedEventArgs e)
        {
            TimeSpan ts = Media1.NaturalDuration.TimeSpan;
            s1.Maximum = ts.TotalSeconds;
            timer.Start();
        }

        private void Window_Drop(object sender, System.Windows.DragEventArgs e)
        {
            string file = (string)((System.Windows.DataObject)e.Data).GetFileDropList()[0];
            Media1.Source = new Uri(file);
            Media1.LoadedBehavior = MediaState.Manual;
            Media1.UnloadedBehavior = MediaState.Manual;
            Media1.Volume = (double)s2.Value;
            Media1.Play();
        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                AddExtension = true,
                DefaultExt = "*.*",
                Filter = "Media Files (*.*)|*.*"
            };
            ofd.ShowDialog();

            try
            {
                Media1.Source = new Uri(ofd.FileName);
                Media1.LoadedBehavior = MediaState.Manual;
                Media1.UnloadedBehavior = MediaState.Manual;
                Media1.Volume = (double)s2.Value;
                Media1.Play();
            }
            catch
            {
                new NullReferenceException("Error");
            }
            System.Windows.Threading.DispatcherTimer dt = new System.Windows.Threading.DispatcherTimer();
            
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(500)
            };
            timer.Tick += new EventHandler(Timer_Tick);
        }

    }
}
