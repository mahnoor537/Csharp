﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Windows.Media;
namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string selectedFileName;
        BitmapImage bitmap = new BitmapImage();
        int angle = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                InitialDirectory = "C:\\",
                RestoreDirectory = true,
                Filter = "Image files (*.jpg,*.jpeg,*.png)|*jpg;*.jpeg;*.png;|All Files(*.*)|*.*"
            };
            if (ofd.ShowDialog()== true)
            {
                selectedFileName = ofd.FileName;
                //BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                img.Source = bitmap;
            }

        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            TransformedBitmap tempImage = new TransformedBitmap();
            tempImage.BeginInit();
            tempImage.Source =bitmap;
            
            RotateTransform transform = new RotateTransform(angle -= 90);
            tempImage.Transform = transform;
            img.Source = tempImage;
            tempImage.EndInit();

        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            if(img.Width<1000 || img.Height<1000)
            {
                img.Width += 100;
                img.Height += 100;
            }
            else
            {
                img.Width = 1000;
                img.Height = 1000;
            }
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            if (img.Width >= 200 || img.Height>=200)
            {
                img.Width -= 100;
                img.Height -= 100;
            }
            else
            {
                img.Width = 0;
                img.Height = 0;
            }
        }

        private void B5_Click(object sender, RoutedEventArgs e)
        {
            TransformedBitmap tempImage = new TransformedBitmap();
            tempImage.BeginInit();
            tempImage.Source = bitmap;

            RotateTransform transform = new RotateTransform(angle += 90);
            tempImage.Transform = transform;
            img.Source = tempImage;
            tempImage.EndInit();
        }
    }
}
