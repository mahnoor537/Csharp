﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Windows.Threading;

namespace WpfApp8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Keys(false);
        }
        char a='n', b='n', c='n', d='n', g='n', f='n';
        DispatcherTimer timer = new DispatcherTimer();
        int t = 0;
        int min = 0;
        int hour = 0;
        int moves = 1;
        int lastclicked = 0;
        int done = 0;

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += OnTickEvent;
            timer.Start();
            Keys(true);
            b1.IsEnabled = false;

        }
        private void OnTickEvent(object sender, EventArgs e)
        {
            t++;
            if (t%2==0)
            {
                turn();
            }
            if (t % 60 == 0)
            {
                t = 0;
                min++;
                if (min % 60 == 0)
                {
                    min = 0;
                    hour++;
                }
            }
            
            t1.Text = "0"+hour+":0"+min + ":" + t.ToString();
        }
        private void eventEnd()
        {
            timer.Stop();
            Keys(false);
            board.Text = "*****YOU DID IT!*****\n\nYou've memorized the chinese symbols of strength in " + moves.ToString() + " Moves!!";
            board.Visibility = System.Windows.Visibility.Visible;
            b1.IsEnabled = false;
        }
        private void turn()
        {
            if (a=='n')
            {
                img1.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img8.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
            if (b=='n')
            {
                img2.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img5.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
            if (c == 'n')
            {
                img3.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img9.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
            if (d == 'n')
            {
                img4.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img11.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
            if (g=='n')
            {
                img6.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img10.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
            if (f == 'n')
            {
                img7.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
                img12.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/white.jpg", UriKind.Absolute));
            }
        }
        private void Keys(bool v)
        {
            c1.IsEnabled = v;
            c2.IsEnabled = v;
            c3.IsEnabled = v;
            c4.IsEnabled = v;
            c11.IsEnabled = v;
            c12.IsEnabled = v;
            c13.IsEnabled = v;
            c14.IsEnabled = v;
            c6.IsEnabled = v;
            c7.IsEnabled = v;
            c8.IsEnabled = v;
            c9.IsEnabled = v;
        }

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            img1.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/Source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangsong.jpg", UriKind.Absolute));
            if (lastclicked != 9)
            { 
                lastclicked = 1;
            }
            else
            {
                a = 'y';
                turn();
                img8.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/Source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangsong.jpg", UriKind.Absolute));
                c1.IsEnabled = false;
                c9.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done==6)
                {
                    eventEnd();
                }
                
            }
            t2.Text = "Moves:"+(moves++).ToString();
        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            img2.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiyuan.jpg", UriKind.Absolute));
            if (lastclicked != 6)
            {
                lastclicked = 2;
            }
            else
            {
                b = 'y';
                turn();
                c2.IsEnabled = false;
                c6.IsEnabled = false;
                img5.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiyuan.jpg", UriKind.Absolute));
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            img3.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangzhengfat.jpg", UriKind.Absolute));
            if (lastclicked != 11)
            {
                
                lastclicked = 3;
            }
            else
            {
                c = 'y';
                turn();
                img9.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangzhengfat.jpg", UriKind.Absolute));
                c3.IsEnabled = false;
                c11.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                  
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C4_Click(object sender, RoutedEventArgs e)
        {
            img4.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-littleseal.jpg", UriKind.Absolute));
            if (lastclicked != 13)
            {
                
                lastclicked = 4;
            }
            else
            {
                d = 'y';
                turn();
                img11.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-littleseal.jpg", UriKind.Absolute));
                c13.IsEnabled = false;
                c4.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                   
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C6_Click(object sender, RoutedEventArgs e)
        {
            img5.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiyuan.jpg", UriKind.Absolute));
            if (lastclicked != 2)
            {
               
                lastclicked = 6;
            }
            else
            {
                b = 'y';
                turn();
                img2.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiyuan.jpg", UriKind.Absolute));
                c2.IsEnabled = false;
                c6.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                   
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C7_Click(object sender, RoutedEventArgs e)
        {
            img6.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiangli.jpg", UriKind.Absolute));
            if (lastclicked != 12)
            {
                
                lastclicked = 7;
            }
            else
            {
                g = 'y';
                turn();
                img10.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiangli.jpg", UriKind.Absolute));
                c7.IsEnabled = false;
                c12.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C8_Click(object sender, RoutedEventArgs e)
        {
            img7.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-lidi.jpg", UriKind.Absolute));
            if (lastclicked != 14)
            {
                
                lastclicked = 8;
            }
            else
            {
                f = 'y';
                turn();
                img12.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-lidi.jpg", UriKind.Absolute));
                c8.IsEnabled = false;
                c14.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C9_Click(object sender, RoutedEventArgs e)
        {
            img8.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/Source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangsong.jpg", UriKind.Absolute));
            if (lastclicked != 1)
            {
                
                lastclicked = 9;
            }
            else
            {
                a = 'y';
                turn();
                img1.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/Source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangsong.jpg", UriKind.Absolute));
                c1.IsEnabled = false;
                c9.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }
        private void C11_Click(object sender, RoutedEventArgs e)
        {
            img9.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangzhengfat.jpg", UriKind.Absolute));
            if (lastclicked != 3)
            {
                
                lastclicked = 11;
            }
            else
            {
                c = 'y';
                turn();
                img3.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-fangzhengfat.jpg", UriKind.Absolute));
                c11.IsEnabled = false;
                c3.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }

        private void C12_Click(object sender, RoutedEventArgs e)
        {
            img10.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiangli.jpg", UriKind.Absolute));
            if (lastclicked != 7)
            {
                
                lastclicked = 12;
            }
            else
            {
                g = 'y';
                turn();
                img6.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-xiangli.jpg", UriKind.Absolute));
                c12.IsEnabled = false;
                c7.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();

        }

        private void C13_Click(object sender, RoutedEventArgs e)
        {
            img11.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-littleseal.jpg", UriKind.Absolute));
            if (lastclicked != 4)
            {
                
                lastclicked = 13;
            }
            else
            {
                d = 'y';
                turn();
                img4.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-littleseal.jpg", UriKind.Absolute));
                c4.IsEnabled = false;
                c13.IsEnabled = false;
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();

        }

        private void C14_Click(object sender, RoutedEventArgs e)
        {
            img12.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-lidi.jpg", UriKind.Absolute));
            if (lastclicked != 8)
            {
                
                lastclicked = 14;
            }
            else
            {
                f = 'y';
                turn();
                c14.IsEnabled = false;
                c8.IsEnabled = false;
                img7.Source = new BitmapImage(new Uri("C:/Users/Mahnoor/source/repos/WpfApp8/WpfApp8/Resources/chinese-symbol-for-strength-lidi.jpg", UriKind.Absolute));
                if (done < 6)
                {
                    done++;
                }
                if (done == 6)
                {
                    
                    eventEnd();
                }

            }
            t2.Text = "Moves:" + (moves++).ToString();
        }
    }
}
