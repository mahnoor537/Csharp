﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WpfApp7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }
        static SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Mahnoor\source\repos\WpfApp7\WpfApp7\data.mdf;Integrated Security=True;User Instance=True");
       
        private void B1_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            tb2.Text = " ";
            tb3.Text = " ";
            tb6.Text = " ";
            p1.Password= " ";
            p2.Password = " ";
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
                if (tb3.Text.Length == 0)
                {
                    errormessage.Text = "Enter an email.";
                    tb3.Focus();
                }
                else if (!Regex.IsMatch(tb3.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
                {
                    errormessage.Text = "Enter a valid email.";
                    tb3.Select(0, tb3.Text.Length);
                    tb3.Focus();
                }
                else
                {
                    string name = tb2.Text;
                    string email = tb3.Text;
                    string password = p1.Password;
                    if (p1.Password.Length == 0)
                    {
                        errormessage.Text = "Enter password.";
                        p1.Focus();
                    }
                    else if (p2.Password.Length == 0)
                    {
                        errormessage.Text = "Enter Confirm password.";
                        p2.Focus();
                    }
                    else if (p1.Password != p2.Password)
                    {
                        errormessage.Text = "Confirm password must be same as password.";
                        p2.Focus();
                    }
                    else
                    {
                        errormessage.Text = "";
                        string address = tb6.Text;
                        con.Open();
                        string query = "insert into UserData(Name,EmailID,Password,Address) values('"+name+"','"+ email +"','"+ password +"','"+ address+"')";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        errormessage.Text = "You have Registered successfully.";
                        Reset();
                        con.Close();
                    }
                }
            }
     

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            SignIn login = new SignIn();
            login.ShowDialog();
            this.Close();
        }
    }
}
