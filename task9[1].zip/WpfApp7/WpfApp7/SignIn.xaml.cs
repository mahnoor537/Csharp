﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WpfApp7
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class SignIn : Window
    {
        public SignIn()
        {
            InitializeComponent();
            
        }
        
        Welcome welcome = new Welcome();
        private void Bu1_Click(object sender, RoutedEventArgs e)
        {
            if (t2.Text.Length == 0)
            {
                errormessage1.Text = "Enter an email.";
                t2.Focus();
            }
            else if (!Regex.IsMatch(t2.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {
                errormessage1.Text = "Enter a valid email.";
                t2.Select(0, t2.Text.Length);
                t2.Focus();
            }
            else
            {
                string email = t2.Text;
                string password = pass1.Password;
                SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Mahnoor\source\repos\WpfApp7\WpfApp7\data.mdf;Integrated Security=True;User Instance=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UserData where EmailID='" + email + "'  and password='" + password + "'", con)
                {
                    CommandType = CommandType.Text
                };
                SqlDataAdapter adapter = new SqlDataAdapter
                {
                    SelectCommand = cmd
                };
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    string username = dataSet.Tables[0].Rows[0]["Name"].ToString();
                    welcome.text1.Text = username;//Sending value from one form to another form.  
                    this.Hide();
                    welcome.ShowDialog();
                    this.Close();
                }
                else
                {
                    errormessage1.Text = "Can't Sign In, Invalid Email/Password";
                }
                con.Close();
            }
        }

        private void Bu2_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            SignUp registration = new SignUp();
            registration.ShowDialog();
            this.Close();
        }
    }
}
