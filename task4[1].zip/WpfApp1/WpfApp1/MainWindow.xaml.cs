﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char opr='c';
        double oprnd1;
        double oprnd2;
        int vr = 0;
        string lastinput;
        public MainWindow()
        {
            InitializeComponent();
            enabler2(false);
        }

        private void enabler2(bool v)
        {
            opr1.IsEnabled = v;
            opr2.IsEnabled = v;
            opr3.IsEnabled = v;
            opr4.IsEnabled = v;
            opr5.IsEnabled = v;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void O9_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o9.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O8_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o8.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O7_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o7.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O6_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o6.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O5_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o5.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O4_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o4.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O3_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o3.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O2_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o2.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O1_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o1.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void O0_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += o0.Content.ToString();
            vr = 0;
            enabler2(true);
        }

        private void Opr1_Click(object sender, RoutedEventArgs e)
        {
            if (vr == 0)
            {
                oprnd1 = double.Parse(tb1.Text);
                opr = '+';
                tb1.Text =" ";
                vr += 1;
            }
            else
            {
                lastinput = tb1.Text.Substring(0, tb1.Text.Length - 1);
                tb1.Text = "MathError: Invalid Expression, Press Ok to Continue.";
                Keys(false);
                ok.IsEnabled = true;
            }
        }

        private void Opr2_Click(object sender, RoutedEventArgs e)
        {
            if (vr == 0)
            {
                oprnd1 = double.Parse(tb1.Text);
                opr = '-';
                tb1.Text = "";
                vr += 1;
            }
            else
            {
                lastinput=tb1.Text.Substring(0, tb1.Text.Length - 1); 
                tb1.Text = "MathError: Invalid Expression, Press Ok to Continue.";
                Keys(false);
                ok.IsEnabled = true;
            }
        }

        private void Opr3_Click(object sender, RoutedEventArgs e)
        {
            if (vr == 0)
            {
                oprnd1 = double.Parse(tb1.Text);
                opr = '*';
                tb1.Text = "";
                vr += 1;
            }
            else
            {
                lastinput = tb1.Text.Substring(0, tb1.Text.Length - 1);
                tb1.Text = "MathError: Invalid Expression, Press Ok to Continue.";
                Keys(false);
                ok.IsEnabled = true;
            }
        }

        private void Opr4_Click(object sender, RoutedEventArgs e)
        {
            if (vr == 0)
            {
                oprnd1 = double.Parse(tb1.Text);
                opr = '/';
                tb1.Text = "";
                vr += 1;
            }
            else
            {
                lastinput = tb1.Text.Substring(0, tb1.Text.Length - 1);
                tb1.Text = "MathError: Invalid Expression, Press Ok to Continue.";
                Keys(false);
                ok.IsEnabled = true;
            }
        }

        private void Opr5_Click(object sender, RoutedEventArgs e)
        {
            oprnd2 = double.Parse(tb1.Text);
            switch(opr)
            {
                case '+':
                    tb1.Text = (oprnd1 + oprnd2).ToString();
                    break;
                case '-':
                    tb1.Text = (oprnd1 - oprnd2).ToString();
                    break;
                case '*':
                    tb1.Text = (oprnd1 * oprnd2).ToString();
                    break;
                case '/':
                    if (oprnd2 == 0)
                    {
                        tb1.Text = "MathError: Division by Zero,Press Clear to Continue";
                        Keys(false);
                    }
                    else
                        tb1.Text = (oprnd1 / oprnd2).ToString();
                    break;
            }
            
        }

        private void Keys(bool f)
        {
            del.IsEnabled = f;
            o1.IsEnabled = f;
            o2.IsEnabled = f;
            o3.IsEnabled = f;
            o4.IsEnabled = f;
            o5.IsEnabled = f;
            o6.IsEnabled = f;
            o7.IsEnabled = f;
            o8.IsEnabled = f;
            o9.IsEnabled = f;
            o0.IsEnabled = f;
            opr1.IsEnabled =f;
            opr2.IsEnabled = f;
            opr3.IsEnabled = f;
            opr4.IsEnabled = f;
            opr5.IsEnabled = f;
            point.IsEnabled = f;
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            oprnd1 = 0;
            oprnd2 = 0;
            tb1.Text = "";
            opr = 'c';
            Keys(true);
        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            if (tb1.Text.Length>0)
                tb1.Text = tb1.Text.Substring(0,tb1.Text.Length - 1);
        }

        private void Point_Click(object sender, RoutedEventArgs e)
        {
            if (tb1.Text.Contains('.'))
            {
                lastinput= tb1.Text;
                tb1.Text = "MathError: Can't have two decimal points in one expression!, Press Ok to Continue.";
                Keys(false);
                ok.IsEnabled = true;
            }
            else
            {
                tb1.Text += point.Content.ToString();
                vr = 0;
             }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text = lastinput;
            ok.IsEnabled = false;
            Keys(true);
        }
    }
}
